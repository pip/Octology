  Version 1.32 [2017/08/28]  Checksum: 1B2F

    = Fixed execution error in Grub4dos environment.

  Version 1.31 [2014/08/01]  Checksum: 1B0D

    = Supported X99-Series [Secure BIOS Update] feature.
    
  Version 1.30 [2011/12/22]  Checksum: D47A

    = Display a message if backup function is not supported.
    = Fixed the bug that program would show "Failed to find the update module"
      at startup if DMI data body was stored at higher than 1MB.

  Version 1.28 [2011/12/20]  Checksum: 0C2F

    + Added .CAP file support for Security Update feature.

  Version 1.26 [2011/04/29]  Checksum: 77C9

    = Fixed the bug that when an NTFS partition's cluster size is smaller than
      its MFT size (e.g., the cluster size is 512KB and the MFT size 1024KB),
      the partition would not be readable.
    = Fixed the bug that drive A: would always be shown in GUI mode even if
      there was no any existent floppy drives.

  Version 1.24 [2011/01/03]  Checksum: 7239

    + Added OakTrail platform support.
    = Revised and updated all the displayed strings.

  Version 1.22 [2010/09/27]  Checksum: 1A9D

    = Removed the Marvell 9120/9123 ODD delay patch. Instead, we force an 8-byte
      boundary data out transfer to dodge the bug in controller's PIO mode.

  Version 1.20 [2010/08/18]  Checksum: 0DD7

    = Fixed the problem that system would hang at startup if boot with WinME DOS
      open disk due to incorrect memory size which INT 15h E801h returned.
    = Fixed the problem that system would hang at startup if there is an exFAT
      partition found. (note: exFAT is still unsupported currently)

  Version 1.18 [2010/04/29]  Checksum: D84C

    = Fixed the problem that total memory size determination would be incorrect
      from INT 15h E801h call when HIMEM.SYS was loaded.

  Version 1.16 [2010/03/23]  Checksum: 8B5E

    = Fixed the wrong flash size value passed to PE DLL's ASEX_get_bios_image
      function, which may cause BIOS backup fail under some conditions.

  Version 1.14 [2010/01/08]  Checksum: 80B4

    * Fixed the hangup problem under diskless PXE environments.

  Version 1.12 [2009/11/19]  Checksum: 708A

    * Support both legacy BIOS and EFI BIOS.
    * Display the model string correctly if there are '-' characters.
    * Fixed the problem that ODDs connected to the Marvell 9123 controller would
      sometimes be not detectable.
    * Refined progress bar display.
    * Removed AFUDOS compatible mode (SMIFLASH interface) support. (option /f)
    * Removed flash type string display.

  Version 1.10 [2009/09/25]  Checksum: 4184

    * Fixed the problem that system might automatically reboot before updating
      BIOS under certain circumstances.

  Version 1.08 [2009/09/04]  Checksum: 3629

    * Fixed the problem that flash size determination would be incorrect if
      there were more than one flash chip.
    * Fixed the typo of word "WARNING", and updated some display message.

  Version 1.06 [2009/08/04]  Checksum: 4B93

    * Fixed the problem that CD/DVD DISC whose TOC control value was not 04h
      would be not readable.
    * Display a message after successful BIOS update in GUI mode.

  Version 1.04 [2009/07/29]  Checksum: 0AAA

    * Fixed a divided by zero problem in flash callback function when the BIOS
      image to be updated is identical to the current BIOS.
    * Fixed the incorrect read count of the ATA data register after issuing an
      ATAPI command to ODD, which may cause some ATAPI controllers to hang.
      (e.g., Marvell 9123)

  Version 1.02 [2009/07/16]  Checksum: 06FA

    * Use BIOS image's internal GetBIOSImage routine to backup BIOS.
    * Display the update success message in command line rather than in GUI,
      so that users do not need to press any key to bypass the message.

  Version 1.00 [2009/07/07]  Checksum: 592B

    * Initial release.
