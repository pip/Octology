// ElementHider - an object for hiding and showing HTML elements 

function ElementHider() {

	// attributes

	this.elementToHide     = null;
	this.displayType       = "";
	this.elementToChange   = null;
	this.showWhenHidden    = "";
	this.showWhenDisplayed = "";

	// methods

	// hide element and show text for hidden state
	this.hide = function() {
		this.elementToHide.style.display = 'none';
		if (this.elementToChange) {
			this.elementToChange.innerHTML = this.showWhenHidden;
		}
	}

	// show element and show text for displayed state
	this.show = function() {
		this.elementToHide.style.display = this.displayType;
		if (this.elementToChange) {
			this.elementToChange.innerHTML = this.showWhenDisplayed;
		}
	}

	// whatever state the current element is in, switch it
	this.toggle = function() {
		if (this.elementToHide.style.display == 'none') {
			this.show();
		} else {
			this.hide();
		}
	}

}

/*

=head1 NAME

ElementHider - an object for hiding and showing HTML elements

=head1 SYNOPSIS

Set up some HTML that will use the C<hider> object.

  <a id="report_toggle_link" href="#" onClick="hider.toggle()"> [hide] </a>
  <div id="report">
    <& crazy_mason_report, %ARGS &>
  </div>

Create and configure C<hider> object to work with the HTML above.

  var hider = new ElementHider();
  hider.elementToHide     = document.getElementById('report');
  hider.elementToChange   = document.getElementById('report_toggle_link');
  hider.showWhenHidden    = "[show]";
  hider.showWhenDisplayed = "[hide]";

=head1 DESCRIPTION

Lately, the production crew at Oversee has been asking developers to
implement a way to hide and show blocks of HTML while simultaneously
changing the content of the page.  This is so that when a block is
hidden the link to show the block again will say "show" and when the
block is displayed, the link to make the block go away will say "hide".

To facilitate this, this JavaScript object was implemented.

=head1 ATTRIBUTES

=head2 elementToHide

HTMLElement object that you want to hide and show

=head2 elementToChange

HTMLElement object that you want to change the C<innerHTML> attribute of

=head2 showWhenHidden

text to put into C<this.elementToChange.innerHTML> when C<this.elementToHide>
is hidden

=head2 showWhenDisplayed

text to put into C<this.elementToChange.innerHTML> when C<this.elementToHide>
is displayed

=head1 METHODS

=head2 hide()

This method hides the block specified by C<this.elementToHide>.  If
C<this.elementToChange> is specified, the text from C<this.showWhenHidden> will
replace the content of C<this.elementToChange>.

=head2 show()

This method shows the block specified by C<this.elementToHide>.  If
this.elementToChange is specified, the text from C<this.showWhenDisplayed> will
replace the content of C<this.elementToChange>.

=head2 toggle()

If C<this.elementToHide> is hidden, call C<this.show()> .  Else, call
C<this.hide()>.

=head1 AUTHOR

John Beppu <john.beppu@gmail.com>

=cut

*/
