/*  JavaScript for BlogSource.com */


/* Runs at the onload() event of the <body> tag.  Anything you put in here will 
   be run when the page loads.
--------------------------------------------------------------------------------*/
function loadall() {
	externallinks();
	zebratables();
	dropdowns();
}



/**
 *   Array convenience method to check for membership.
 *
 *   @param object element
 *   @returns boolean
 */
Array.prototype.contains = 
	function(element) {
		for (var i = 0; i < this.length; i++) {
			if (this[i] == element) {  return true; }
		}
		return false;
	};






/* Makes any link to which you add rel="external" open in a new window. 
   SEE: http://www.sitepoint.com/article/standards-compliant-world
--------------------------------------------------------------------------------*/
function externallinks() {
	if(!document.getElementsByTagName) return;
	var anchors = document.getElementsByTagName("a");
	
	for (var i = 0; i < anchors.length; i++) {
		var anchor = anchors[i];
		if ( anchor.getAttribute("href") && (anchor.getAttribute("rel") == "external") ) {
			anchor.target = "_blank";
		}
	}	
}



/* When you click the image inside a label, it triggers the onclick for the 
   <input> next to it by passing in their shared parent node
--------------------------------------------------------------------------------*/
function triggerinput(parent_node) {
	var inputs = parent_node.getElementsByTagName('input');
	inputs[0].click(); // triggers onclick event for the radio button
}



/* restricts keypresses to 0-9, and basics like backspace, delete, and arrow keys
--------------------------------------------------------------------------------*/
function allowonlydigits(the_event) {
	var key = the_event.keyCode; // for IE5/Mac
	var key = key ? key : the_event.which;
	return ( (key <= 57) && !(key >= 33 && key <= 47) ) ? true : false;
}
	
	
/* applies classes to create zebra stripes, stripe on hover, and stripe when clicked
--------------------------------------------------------------------------------*/
function zebratables() {
	if(!document.createTextNode){ return; }
	
	var tableClass = 'zebra';
	var colorClass = 'stripe';
	var hoverClass = 'row_hover';
	var activeClass = 'row_active';
	var nonZebra = Array('totals', 'subhead');
	var noRule = 'norule';
	var alltables, bodies, i, j, k, addClass, trs, c, a; 
	var stripe, offset = 1, offsetMode;
	alltables = document.getElementsByTagName('table');
	
	
	
	
	for (k = 0 ; k < alltables.length ; k++) {
		if ( !alltables[k].className.match(tableClass) ) { continue; }
		bodies = alltables[k].getElementsByTagName('tbody');
		
		for (i = 0 ; i < bodies.length ; i++) {
			trs = bodies[i].getElementsByTagName('tr');
			
			for (j = 0 ; j < trs.length ; j++) {
				if (!nonZebra.contains(trs[j].className)) {
					if(trs[j].getElementsByTagName('td').length > 0) {
						stripe = (offset + j)%2;
						offsetMode = 0;
						trs[j].className += stripe ? (' ' + colorClass) : '';
						
						/* // Clicking a row toggles hoverClass
						trs[j].onclick = 
							function() {
								if(this.className.match(activeClass)) {
									var rep = this.className.match(' ' + activeClass) ? (' ' + activeClass) : activeClass;
									this.className = this.className.replace(rep, '');
								} else {
									this.className += this.className ? (' ' + activeClass) : activeClass;
								}
							}
						*/
						
						if (!alltables[k].className.match(noRule)) {
							trs[j].onmouseover = function() { this.className = this.className + ' ' + hoverClass; }
													
							trs[j].onmouseout = 	
								function() {
									var rep = this.className.match(' ' + hoverClass) ? (' ' + hoverClass) : hoverClass;
									this.className = this.className.replace(rep, '');
								}
						}
					}
				} else {
					if(!offsetMode) {
						offsetMode = 1; 
						offset = ((j + 1)%2 == 0) ? 1 : 0; // set offset so the next good row will be colored
					} else {
						offset++; // maintain that the next good row will be colored
					}
	
				}
			}
		}
	}		
} 


	
/* Emulates :hover functionality on <li>s for Suckerfish Dropdowns
   SEE: http://www.alistapart.com/articles/dropdowns/
--------------------------------------------------------------------------------*/
function dropdowns() {
	if (document.all && document.getElementById) { // check if IE
		navRoot = document.getElementById("nav_menu");
		lis = navRoot.getElementsByTagName('li');
		for (i = 0; i < lis.length; i++) {
			//lis[i].className += " over";
			lis[i].onmouseover = 
				function() { 
					//alert(this.className);
					var before = this.className.match(' normal') ? ' normal' : 'normal';
					var after = (before == ' normal') ? ' over' : 'over';
					this.className = this.className.replace(before, after);
				}
				
			lis[i].onmouseout = 
				function() { 
					var before = this.className.match(' normal') ? ' normal' : 'normal';
					var after = (before == ' normal') ? ' over' : 'over';
					this.className = this.className.replace(after, before);
					//alert(this.className);
				}
		}
	}
}
	

/* open a popup window with default attributes
--------------------------------------------------------------------------------*/
function popup(url, name, attr) {
	if (!name) { name = 'popup'; }
	if (!attr) { attr = "width=415, height=225, location=no, menubar=no, status=no, toolbar=no, scrollbars=no, resizable=no, directories=no"; }
	var win = window.open(url, name, attr);
	win.focus();
}


	
